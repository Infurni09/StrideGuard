## StrideGuard threat model — {{ analysis.timestamp }}

{% if threats.total == 0 %}
No threats identified in this diff. StrideGuard reviewed all six STRIDE
categories against the changed code and found no actionable security concerns.

*If you believe this is incorrect, add the `needs-threat-model` label to
trigger a manual re-analysis with a description of the feature.*
{% else %}
StrideGuard identified **{{ threats.total }} threat(s)** across
{{ threats.categories_affected }} STRIDE categories.

### Findings

| ID | Severity | Category | Component | Issue |
|----|----------|----------|-----------|-------|
{% for threat in threats.list %}
| `{{ threat.id }}` | {{ threat.severity_badge }} | {{ threat.category }} | `{{ threat.component }}` | #{{ threat.issue_iid }} |
{% endfor %}

### Severity breakdown

| Severity | Count |
|----------|-------|
| 🔴 Critical | {{ threats.critical }} |
| 🟠 High     | {{ threats.high }} |
| 🟡 Medium   | {{ threats.medium }} |
| 🔵 Low      | {{ threats.low }} |

{% if threats.critical > 0 or threats.high > 0 %}
> **Action required:** This MR contains Critical or High severity threats.
> Please address the linked issues before merging.
{% endif %}

### Re-analysis

StrideGuard will automatically re-analyze this MR when new commits are pushed.
Resolved threats will be closed automatically. To trigger a manual re-analysis,
remove and re-add the `needs-threat-model` label.
{% endif %}

---

*[StrideGuard](https://gitlab.com/gitlab-ai-hackathon/strideguard) — AI Threat Modeling Agent | [How to configure](https://gitlab.com/gitlab-ai-hackathon/strideguard#configuration)*
